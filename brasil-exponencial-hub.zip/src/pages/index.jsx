import Hero from "../components/Hero";
import ProductSection from "../components/ProductSection";
import CommunitySection from "../components/CommunitySection";
import InvestorSection from "../components/InvestorSection";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <main className="bg-black text-white">
      <Hero />
      <ProductSection />
      <CommunitySection />
      <InvestorSection />
      <Footer />
    </main>
  );
}