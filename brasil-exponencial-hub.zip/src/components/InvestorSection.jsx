export default function InvestorSection() {
  return (
    <section className="p-12 text-center">
      <h2 className="text-3xl font-bold mb-4">Área de Investidores</h2>
      <p className="text-gray-400 mb-6">
        Invista no futuro dos humanoides e operadores autônomos. O amanhã começa aqui.
      </p>
    </section>
  );
}