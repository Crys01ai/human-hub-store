export default function Hero() {
  return (
    <section className="text-center py-24 bg-gradient-to-b from-gray-900 to-black">
      <h1 className="text-5xl font-bold mb-4">Human Hub Store</h1>
      <p className="text-xl text-gray-300">Humanóides e Operadores Autônomos Inteligentes</p>
    </section>
  );
}