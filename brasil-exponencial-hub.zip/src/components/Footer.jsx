export default function Footer() {
  return (
    <footer className="text-center p-6 bg-black text-gray-500">
      © 2025 Human Hub Store • Brasil Exponencial Hub
    </footer>
  );
}