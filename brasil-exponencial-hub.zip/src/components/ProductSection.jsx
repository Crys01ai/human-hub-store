export default function ProductSection() {
  return (
    <section className="p-12 text-center">
      <h2 className="text-3xl font-bold mb-4">Humanóides Premium</h2>
      <p className="text-gray-400 mb-6">
        Explore robôs humanoides avançados e operadores autônomos IA que transformam negócios.
      </p>
    </section>
  );
}