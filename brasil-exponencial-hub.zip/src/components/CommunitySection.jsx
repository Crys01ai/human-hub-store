export default function CommunitySection() {
  return (
    <section className="p-12 bg-gray-900 text-center">
      <h2 className="text-3xl font-bold mb-4">Comunidade Brasil Exponencial Hub</h2>
      <p className="text-gray-400 mb-6">
        Conecte-se com mentes exponenciais, empreendedores e investidores em inovação IA.
      </p>
    </section>
  );
}